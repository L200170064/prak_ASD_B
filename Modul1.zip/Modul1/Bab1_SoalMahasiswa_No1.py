class cetakSiku():
    """Buat Fungsi cetakSiku (x)"""

def Siku(n):
    for i in range(n):
        for j in range(i+1):
            print("*", end="")
        print()
    
    
