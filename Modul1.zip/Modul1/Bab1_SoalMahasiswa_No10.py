def selesaikanABC(a,b,c):
    if a <= 0 and b <= 0 and c <= 0:
        print("Determinannya Positif. Persamaan Mempunyai akar Real")
    else:
        print("Determinannya Negatif. Persamaan tidak Mempunyai akar Real")
        
selesaikanABC(1,2,3)
