from math import sqrt as sq
n=100
for i in range(2,50):
	print (i)
