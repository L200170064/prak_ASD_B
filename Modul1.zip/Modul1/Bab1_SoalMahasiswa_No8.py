def apakahTerkandung(h,k):
    return h.lower() in k.lower()

        
